import type { Metadata } from "next";
import { Inter, Space_Grotesk } from "next/font/google";
import "./globals.css";
import { cn } from "@/lib/utils";
import FloatingWhatsApp from "@/components/ui/FloatingWhatsApp";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const spaceGrotesk = Space_Grotesk({
  variable: "--font-heading",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Royal Gold Traders",
  description: "The ultimate centralized platform for premium gold trading.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" style={{ colorScheme: 'dark' }}>
      <body
        className={cn(`${inter.variable} ${spaceGrotesk.variable} antialiased font-sans bg-navy-950 text-white min-h-screen overflow-x-hidden`)}
      >
        {children}
        <FloatingWhatsApp />
      </body>
    </html>
  );
}
